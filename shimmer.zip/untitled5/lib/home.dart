import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children:
        [
        ListView.builder(
          shrinkWrap: true,
        itemCount: 10,
        itemBuilder: (BuildContext context, int index) {
          return Shimmer.fromColors(
            baseColor: Colors.lightBlueAccent,
            highlightColor: Colors.lightBlue,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.grey,
                radius: 30,
              ),
              title: Container(
                height: 20,
                color: Colors.grey,
              ),
              subtitle: Container(
                height: 15,
                color: Colors.grey,
              ),
              trailing: Container(
                width: 50,
                height: double.infinity,
                color: Colors.grey,
              ),
            ),
          );
        },
      )
        ]
      )
    );
  }
}
